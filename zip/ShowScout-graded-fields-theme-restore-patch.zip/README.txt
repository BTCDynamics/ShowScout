ShowScout Graded Find + Theme Restore Patch

Replace/add these files in your ShowScout project:

- app.py
- models.py
- templates/base.html
- templates/add_find.html
- templates/show_detail.html
- templates/find_detail.html
- static/manifest.webmanifest
- static/icons/showscout-icon-180.png
- static/icons/showscout-icon-192.png
- static/icons/showscout-icon-512.png

What changed:
- Restores the ShowScout dark/gold mobile-first theme in base.html.
- Keeps the PWA / Add to Home Screen metadata and icons.
- Adds grading_company and grade fields to Find.
- Adds safe SQLite column checks for existing databases.
- Shows Grading Company and Grade only when Raw or Graded = Graded.
- Displays grading info on Show Detail and Find Detail.

After replacing files, restart Flask or redeploy Render.
