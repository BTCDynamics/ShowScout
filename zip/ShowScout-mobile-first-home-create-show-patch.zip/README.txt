ShowScout mobile-first home/create-show patch

Replace these files:
- templates/base.html
- templates/home.html
- templates/create_show.html

No Python/database changes are included.
This keeps the existing app.py and routes intact while making the first screens phone-friendly.
