# ShowScout PWA / Add to Home Screen Patch

Replace/add these files in your ShowScout project:

- `templates/base.html`
- `static/manifest.webmanifest`
- `static/icons/showscout-icon-180.png`
- `static/icons/showscout-icon-192.png`
- `static/icons/showscout-icon-512.png`

## What this adds

This adds basic PWA/mobile home-screen support so users can open ShowScout from an app-style icon on their phone.

## iPhone test

1. Open ShowScout in Safari.
2. Tap Share.
3. Tap **Add to Home Screen**.
4. Confirm the name ShowScout.

## Android test

1. Open ShowScout in Chrome.
2. Tap the menu.
3. Tap **Add to Home screen** or **Install app**.

No Python/database changes are required.
