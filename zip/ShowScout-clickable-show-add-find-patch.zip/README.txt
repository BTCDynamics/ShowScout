ShowScout clickable-show + Add Find patch

Replace these files:
- app.py
- models.py
- templates/home.html
- templates/show_detail.html
- templates/add_find.html
- templates/find_detail.html

What this adds:
- Click a show from the home page.
- View a show detail page.
- Add a find with table number, dealer/company, listed price, raw/graded, status, and notes.
- View saved finds for that show.
- View a basic find detail page.

Database note:
- Adds Find.card_type.
- app.py includes a small SQLite migration helper so an existing showscout.db gets the new column without wiping your existing test shows/finds.
