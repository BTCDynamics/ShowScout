ShowScout Photo Upload Patch

Replace these files:
- app.py
- models.py
- templates/add_find.html
- templates/show_detail.html
- templates/find_detail.html

Also make sure this folder exists in your project:
- static/uploads/

What this adds:
- Photo field on Add Find
- Phone camera support through the browser file input
- Saves uploaded photos into static/uploads/
- Stores the filename on Find.image_filename
- Shows thumbnails on the show detail page
- Shows a larger image on the find detail page

After replacing files:
1. Restart Flask locally.
2. Open an existing show.
3. Add Find.
4. Choose/take a photo.
5. Save.
6. Confirm the thumbnail appears in the Saved Finds list.

Notes:
- No database wipe is needed.
- app.py includes a safe column check for image_filename and card_type.
- On Render, static/uploads is not persistent unless configured with persistent storage. For MVP testing, this is okay, but long-term photo storage should be moved to persistent disk or cloud storage.
